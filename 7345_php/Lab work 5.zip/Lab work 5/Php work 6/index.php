<html>
<head>
	<title>Form Test</title>
</head>
<body>
	<h1>Welcome!</h1>
	<form method="get" action="process-my-form.php">
		What's the password ? <input type="text" name="password"/></br>
		<input type="submit" value="ok, send it!"/>
	</form>
</body>
</html>