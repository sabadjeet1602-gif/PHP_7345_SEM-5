<!DOCTYPE html>
<html>
<body>

<form method="post">
    Enter array values separated by commas:
    <input type="text" name="arr">
    <input type="submit" value="Reverse">
</form>

<?php
if (isset($_POST['arr'])) {
    $array = explode(",", $_POST['arr']);

    echo "<br>Original Array: ";
    foreach ($array as $value) {
        echo trim($value) . " ";
    }

    $reverse = array_reverse($array);

    echo "<br>Reversed Array: ";
    foreach ($reverse as $value) {
        echo trim($value) . " ";
    }
}
?>

</body>
</html>