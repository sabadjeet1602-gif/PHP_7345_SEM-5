<?php
setcookie("username", "Mahavir", time() + 3600);

header("Location: welcome.php");
exit();
?>