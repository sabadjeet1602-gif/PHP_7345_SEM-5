<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "ajax_db"
);

if (!$conn) {
    die("Database Connection Failed");
}

if (isset($_GET['search'])) {

    $search = $_GET['search'];

    $sql = "SELECT name
            FROM students
            WHERE name LIKE '%$search%'";

    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {

        while ($row = mysqli_fetch_assoc($result)) {

            echo "<p>" . $row['name'] . "</p>";

        }

    } else {

        echo "No suggestions found";

    }

}

mysqli_close($conn);

?>