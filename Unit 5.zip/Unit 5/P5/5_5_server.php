<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "ajax_db"
);

if (!$conn) {
    die("Database Connection Failed");
}

$id = $_GET['id'];

$sql = "SELECT * FROM students WHERE id = $id";

$result = mysqli_query($conn, $sql);

if ($row = mysqli_fetch_assoc($result)) {

    echo "<h3>Student Details</h3>";

    echo "ID: " . $row['id'] . "<br>";

    echo "Name: " . $row['name'] . "<br>";

    echo "Email: " . $row['email'] . "<br>";

    echo "Course: " . $row['course'];

} else {

    echo "Student Not Found";

}

mysqli_close($conn);

?>