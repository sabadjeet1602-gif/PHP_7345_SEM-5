<h2>Home Page</h2>

<p>
    Welcome to our website.
</p>

<p>
    This content is loaded dynamically using AJAX.
</p>