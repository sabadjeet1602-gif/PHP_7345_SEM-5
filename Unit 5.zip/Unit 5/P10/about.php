<h2>About Us</h2>

<p>
    This is the About section.
</p>

<p>
    The content was loaded without refreshing
    the complete web page.
</p>