<h2>Products</h2>

<ul>

    <li>Laptop</li>

    <li>Mobile Phone</li>

    <li>Keyboard</li>

    <li>Mouse</li>

</ul>