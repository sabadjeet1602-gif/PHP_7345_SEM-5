<?php

if (isset($_GET['name'])) {

    $name = $_GET['name'];

    if ($name != "") {

        echo "Hello " . htmlspecialchars($name);

    } else {

        echo "Please enter your name.";

    }

}

?>