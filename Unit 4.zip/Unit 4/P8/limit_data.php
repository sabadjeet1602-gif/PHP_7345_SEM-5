<?php

$conn = mysqli_connect("localhost", "root", "", "php_practical_db");

$sql = "SELECT * FROM students LIMIT 3";

$result = mysqli_query($conn, $sql);

echo "<h2>First 3 Student Records</h2>";

echo "<table border='1' cellpadding='10'>";

echo "<tr>
        <th>ID</th>
        <th>Roll</th>
        <th>Name</th>
        <th>Marks</th>
      </tr>";

while ($row = mysqli_fetch_assoc($result)) {

    echo "<tr>";

    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['roll'] . "</td>";
    echo "<td>" . $row['student_name'] . "</td>";
    echo "<td>" . $row['marks'] . "</td>";

    echo "</tr>";
}

echo "</table>";

mysqli_close($conn);

?>