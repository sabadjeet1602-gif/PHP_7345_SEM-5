<?php

try {

    $conn = new PDO(
        "mysql:host=localhost;dbname=php_practical_db",
        "root",
        ""
    );

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $id = 2;

    $sql = "UPDATE students_pdo
            SET student_name = 'Rahul Patel',
                marks = 88
            WHERE id = $id";

    $conn->exec($sql);

    echo "Data Updated Successfully Using PDO";

} catch (PDOException $e) {

    echo "Error: " . $e->getMessage();

}

?>