<?php

$conn = mysqli_connect("localhost", "root", "", "php_practical_db");

$id = 2;

$sql = "UPDATE students
        SET student_name = 'Shyam Nimavat',
            marks = 95
        WHERE id = $id";

if (mysqli_query($conn, $sql)) {

    echo "Data Updated Successfully";

} else {

    echo "Error: " . mysqli_error($conn);

}

mysqli_close($conn);

?>