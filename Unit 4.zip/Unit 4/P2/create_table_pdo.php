<?php

$host = "localhost";
$dbname = "php_practical_db";
$username = "root";
$password = "";

try {

    $conn = new PDO(
        "mysql:host=$host;dbname=$dbname",
        $username,
        $password
    );

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "CREATE TABLE students_pdo (
        id INT AUTO_INCREMENT PRIMARY KEY,
        roll INT NOT NULL,
        student_name VARCHAR(100) NOT NULL,
        marks INT NOT NULL
    )";

    $conn->exec($sql);

    echo "Table Created Successfully Using PDO";

} catch (PDOException $e) {

    echo "Error: " . $e->getMessage();

}

?>