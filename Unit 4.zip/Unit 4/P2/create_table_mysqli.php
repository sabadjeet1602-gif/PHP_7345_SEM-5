<?php

$conn = mysqli_connect("localhost", "root", "", "php_practical_db");

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}

$sql = "CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    roll INT NOT NULL,
    student_name VARCHAR(100) NOT NULL,
    marks INT NOT NULL
)";

if (mysqli_query($conn, $sql)) {
    echo "Table Created Successfully";
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);

?>