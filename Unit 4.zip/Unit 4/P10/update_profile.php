<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "php_practical_db"
);

$id = $_POST['id'];

$username = $_POST['username'];

$password = $_POST['password'];

$sql = "UPDATE users
        SET username = '$username',
            password = '$password'
        WHERE id = $id";

if (mysqli_query($conn, $sql)) {

    echo "<h2>Profile Updated Successfully</h2>";

    echo "<a href='edit_profile.php'>
          Back to Profile
          </a>";

} else {

    echo "Error: " . mysqli_error($conn);

}

mysqli_close($conn);

?>