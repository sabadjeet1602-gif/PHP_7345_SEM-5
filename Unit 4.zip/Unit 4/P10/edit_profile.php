<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "php_practical_db"
);

$id = 1;

$sql = "SELECT * FROM users WHERE id = $id";

$result = mysqli_query($conn, $sql);

$user = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Profile</title>
</head>

<body>

<h2>Edit Profile</h2>

<form method="post" action="update_profile.php">

    <input type="hidden"
           name="id"
           value="<?php echo $user['id']; ?>">

    Username:

    <input type="text"
           name="username"
           value="<?php echo $user['username']; ?>"
           required>

    <br><br>

    Password:

    <input type="password"
           name="password"
           value="<?php echo $user['password']; ?>"
           required>

    <br><br>

    <input type="submit"
           value="Update Profile">

</form>

</body>
</html>