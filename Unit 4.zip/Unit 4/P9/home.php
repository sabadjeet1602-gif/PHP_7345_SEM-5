<!DOCTYPE html>
<html>
<head>
    <title>Home Page</title>
</head>

<body>

<h1>Welcome to Home Page</h1>

<p>You have successfully logged in.</p>

</body>
</html>