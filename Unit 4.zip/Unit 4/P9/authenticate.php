<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "php_practical_db"
);

if (!$conn) {
    die("Connection Failed");
}

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users
        WHERE username = '$username'
        AND password = '$password'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {

    echo "<h2>Login Successful</h2>";

    echo "<p>Welcome " . $username . "</p>";

    echo "<a href='home.php'>Go to Home Page</a>";

} else {

    echo "<h2>Error</h2>";

    echo "<p>Invalid Username or Password</p>";

    echo "<a href='login.php'>Try Again</a>";

}

mysqli_close($conn);

?>