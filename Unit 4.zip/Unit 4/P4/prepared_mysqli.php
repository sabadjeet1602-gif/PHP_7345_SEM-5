<?php

$conn = mysqli_connect("localhost", "root", "", "php_practical_db");

if (!$conn) {
    die("Connection Failed");
}

$roll = 103;
$name = "Amit";
$marks = 75;

$stmt = mysqli_prepare(
    $conn,
    "INSERT INTO students (roll, student_name, marks)
     VALUES (?, ?, ?)"
);

mysqli_stmt_bind_param(
    $stmt,
    "isi",
    $roll,
    $name,
    $marks
);

if (mysqli_stmt_execute($stmt)) {
    echo "Data Inserted Successfully Using Prepared Statement";
} else {
    echo "Error";
}

mysqli_stmt_close($stmt);
mysqli_close($conn);

?>