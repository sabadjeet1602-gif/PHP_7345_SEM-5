<?php

try {

    $conn = new PDO(
        "mysql:host=localhost;dbname=php_practical_db",
        "root",
        ""
    );

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "INSERT INTO students_pdo (roll, student_name, marks)
            VALUES (102, 'Rahul', 90)";

    $conn->exec($sql);

    echo "Data Inserted Successfully Using PDO";

} catch (PDOException $e) {

    echo "Error: " . $e->getMessage();

}

?>