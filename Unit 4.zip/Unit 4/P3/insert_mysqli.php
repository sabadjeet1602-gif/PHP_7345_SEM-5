<?php

$conn = mysqli_connect("localhost", "root", "", "php_practical_db");

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}

$roll = 101;
$name = "Shyam";
$marks = 85;

$sql = "INSERT INTO students (roll, student_name, marks)
        VALUES ('$roll', '$name', '$marks')";

if (mysqli_query($conn, $sql)) {
    echo "Data Inserted Successfully";
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);

?>